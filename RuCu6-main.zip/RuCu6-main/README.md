# RuCu6
这傻逼喜欢拿删库跑路威胁别人，有备无患
===================================
既要享受GitHub带来的便利，又不想别人只fork不提pr

天天当fork警察高强度搜索自己

![SBRUCU62](https://github.com/user-attachments/assets/ca5abf83-2c62-4ce7-95c4-b2529ce73aa3)

你所有仓库里的代码全是你自己写的吗？你要求别人fork后必须提pr，你自己做到了吗？

别人只fork不提pr你就骂别人剽窃，那请问你这无耻小贼偷了别人多少代码？

<img width="937" alt="image" src="https://github.com/user-attachments/assets/b55d0a87-9874-4082-b026-3cbcbb5bfb42">

别人的代码你偷来就用顺手的很哈

<img width="489" alt="image" src="https://github.com/user-attachments/assets/4f699721-442b-4c53-9e45-7cf59b5e9977"><img width="308" alt="image" src="https://github.com/user-attachments/assets/94f2be19-5acc-4894-9939-99e0f4bb5cae">

<img width="511" alt="image" src="https://github.com/user-attachments/assets/7cee1450-697a-48a1-b5ef-200905f91138"><img width="342" alt="image" src="https://github.com/user-attachments/assets/5b4b8396-fee7-4c1f-9c64-2c5c8fb82f77">

<img width="317" alt="image" src="https://github.com/user-attachments/assets/9c99bb57-4687-495d-9b7f-31ee31ba3270"><img width="295" alt="image" src="https://github.com/user-attachments/assets/f16c615a-e14d-4e31-848a-26192880fb11">

偷别人代码上传到自己原创的仓库建群吸粉，还无缘无故骂别人傻逼。

别人涨赞助费关你这臭傻逼什么事啊？你羡慕了？

![SBRUCU65](https://github.com/user-attachments/assets/9ac4593e-5f2d-4aba-9e19-642d91406a95)

以上只是保留了来源的三例，你仓库里还有很多**没有注明来源但编码风格不一**的代码

一下是驼峰命名一下又下划线命名，一下混淆一下又不混淆...

这些代码真不是你这无耻小贼剽窃来的吗？

你偷这么多代码还振振有词骂别人剽窃，你有一丝廉耻心吗？你哪来的脸啊？你有家教吗？

彻头彻尾的双标怪，恬不知耻的乐色人

> “欢迎投稿，分享各种去广告规则，人多力量大！”

免费帮你中译中：欢迎大伙免费提供代码供我吸粉变现，人多变现快！黑奴速来！

![SBRUCU64](https://github.com/user-attachments/assets/1e9dc133-805e-4fc2-ae36-4687a24ca6d4)

还动不动拿删库跑路威胁大家哈哈哈。你威胁的了谁？就你会点代码？有谁逼你写代码开源代码了？想滚赶紧滚

希望你这种只要pr不要fork的开源蛀虫代码黑洞早点滚出Github，别给用汉字的人丢脸了

![SBRUCU61](https://github.com/user-attachments/assets/87d4ca91-d2d9-4a27-98b0-7ca84ae72652)

你哪来的脸要大伙人肉俺好给你出气呀??.??没皮没脸的东西 

还污蔑俺剽窃哈哈哈，文件提交记录大伙都能看见，这话也就骗骗白痴了

俺可不像你那样偷偷下载到本地再当作自己代码上传到自己的原创仓库，俺也从没说过是俺写的，更没有拿着这些代码去吸粉

![SBRUCU63](https://github.com/user-attachments/assets/b98deec1-ae4c-48b6-88d8-016af07fb57a)

动不动就挂人？在猪圈里耍威风耍习惯了？俺可不惯着畜生

你这带砖生是不会开盒只会嘴硬吗？要俺示范一遍吗？
